# plumbing-console
Lightweight MCP (Digital Me) prototype / plumbing console

Purpose
- Central dispatch for orchestrating repository_dispatch events to GitHub repos.
- Signed audit transcripts, basic RBAC hooks (placeholder), and telemetry stubs.
- Intended as a scaffold you can expand and harden (HSM, OIDC, vault, RiverOS).

Contents
- `server/` - Express-based MCP dispatch service
- `.github/workflows/ci.yml` - simple CI
- `examples/` - sample `manifest.json` and usage examples
- `Dockerfile` - to containerize the service
- `.env.example` - environment variables to configure the service

Quick start (local)
1. Copy `.env.example` -> `.env` and fill values (GH_TOKEN etc).
2. Install dependencies:
   ```bash
   cd server
   npm install
   ```
3. Run:
   ```bash
   node src/index.js
   ```
4. Dispatch example:
   ```bash
   curl -X POST http://localhost:4000/api/v1/dispatch \
     -H "Authorization: Bearer YOUR_MCP_BOOTSTRAP_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{ "actor":"kay@believers", "repo":"believers-common/virtual-silk-road", "mode":"textile", "action":"supply-recce" }'
   ```

Security notes
- This scaffold uses a simple HMAC signing placeholder. Replace with HSM or Vault-based signing.
- Do not store long-lived GH_TOKEN in plaintext; use secrets manager.
- Add rate-limiting, RBAC, input validation and DPIA before production.


## Added prototypes
- Vault signing helper (vault_signing.js)
- SIWE endpoints and middleware (siwe.js)
- OpenTelemetry stub (otel.js)
- RBAC and two-person approvals (rbac.js)
- Repository workflow template: `.github/workflows/mcp-dispatch-handler.yml`
- Minimal React UI scaffold at `server/ui/`.
