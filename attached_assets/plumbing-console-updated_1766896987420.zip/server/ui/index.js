import React from 'react';
import ReactDOM from 'react-dom/client';
function App(){
  return (
    <div style={{fontFamily:'system-ui', padding:24}}>
      <h1>Plumbing Console (MCP) Dashboard</h1>
      <p>Prototype UI — shows audit and approvals.</p>
      <div id="content"></div>
    </div>
  );
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
