// rbac.js - simple RBAC and two-person approval scaffold (in-memory for prototype)
const approvals = new Map(); // approvalId -> {payload, approvals: Set, required}
const roles = new Map(); // address -> [roles]

function requireRole(address, role){
  const r = roles.get(address) || [];
  return r.includes(role);
}

function addRole(address, role){
  const r = roles.get(address) || [];
  if(!r.includes(role)) r.push(role);
  roles.set(address, r);
}

function createApproval(payload, required = 2){
  const id = 'apr_' + Date.now().toString(36) + '_' + Math.floor(Math.random()*10000);
  approvals.set(id, { payload, approvals: new Set(), required });
  return id;
}

function signApproval(id, signer){
  const rec = approvals.get(id);
  if(!rec) throw new Error('no approval found');
  rec.approvals.add(signer);
  if(rec.approvals.size >= rec.required){
    // approval reached — return payload
    approvals.delete(id);
    return { approved: true, payload: rec.payload };
  }
  return { approved:false, signers: Array.from(rec.approvals) };
}

function listApprovals(){ return Array.from(approvals.entries()).map(([id,v])=>({id,required:v.required,signers:Array.from(v.approvals)})); }

module.exports = { requireRole, addRole, createApproval, signApproval, listApprovals };
