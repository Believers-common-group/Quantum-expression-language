// siwe.js - SIWE (Sign-In With Ethereum) minimal helpers
// Uses: npm i siwe ethers
const { SiweMessage } = require('siwe');
const ethers = require('ethers');
const nonceStore = new Map(); // simple in-memory nonce store for prototype

function generateNonce(){
  const n = ethers.utils.hexlify(ethers.utils.randomBytes(8));
  nonceStore.set(n, Date.now());
  return n;
}

async function verifySiweMessage(message, signature){
  const siwe = new SiweMessage(message);
  const fields = await siwe.validate(signature);
  // fields has address and statement etc.
  return fields;
}

// simple middleware for protected endpoints expecting Authorization: Bearer SIWE <json>
function siweAuthMiddleware(req,res,next){
  const auth = req.headers['authorization']||'';
  if(!auth.startsWith('Bearer ')) return res.status(401).json({error:'missing token'});
  const token = auth.slice(7);
  try {
    const obj = JSON.parse(Buffer.from(token, 'base64').toString());
    // obj should contain {address, message, signature}
    // For prototype, skip full validation; in prod call verifySiweMessage
    req.user = { address: obj.address };
    return next();
  } catch(e){
    return res.status(401).json({error:'invalid siwe token'});
  }
}

module.exports = { generateNonce, verifySiweMessage, siweAuthMiddleware };
