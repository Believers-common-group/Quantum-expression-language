// Minimal MCP dispatch server (prototype)
const express = require('express');
const fetch = require('node-fetch');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

// Added: OpenTelemetry + SIWE + Vault signing + RBAC imports
const { initOtel } = require('./otel');
const { generateNonce, verifySiweMessage, siweAuthMiddleware } = require('./siwe');
const { signWithVault } = require('./vault_signing');
const { requireRole, addRole, createApproval, signApproval, listApprovals } = require('./rbac');

// start OpenTelemetry (best-effort)
initOtel();


const PORT = process.env.PORT || 4000;
const MCP_BOOTSTRAP_TOKEN = process.env.MCP_BOOTSTRAP_TOKEN || 'changeme';
const GH_TOKEN = process.env.GH_TOKEN;
const AUDIT_STORE_PATH = process.env.AUDIT_STORE_PATH || './audit_store.json';

const app = express();
app.use(express.json());

function saveAudit(record){
  let arr = [];
  try { arr = JSON.parse(fs.readFileSync(AUDIT_STORE_PATH)); } catch(e){}
  arr.push(record);
  fs.writeFileSync(AUDIT_STORE_PATH, JSON.stringify(arr, null, 2));
}

// very small helper: sign payload with HMAC-like placeholder (replace with HSM)
const crypto = require('crypto');
function signPayload(payload){
  // If VAULT_ADDR is configured, use Vault transit signing
  if(process.env.VAULT_ADDR && process.env.VAULT_TOKEN){
    return signWithVault(payload);
  }
  const key = process.env.SIGNING_KEY || 'default-signing-key';
  return crypto.createHmac('sha256', key).update(JSON.stringify(payload)).digest('hex');
}

// simple auth middleware
function authenticate(req,res,next){
  const auth = req.headers['authorization'] || '';
  if(!auth.startsWith('Bearer ')) return res.status(401).json({error:'missing token'});
  const token = auth.slice(7);
  if(token !== MCP_BOOTSTRAP_TOKEN) return res.status(403).json({error:'invalid token'});
  next();
}

app.post('/api/v1/dispatch', authenticate, async (req,res)=>{
  const { actor, repo, mode, action, client_payload } = req.body;
  if(!actor || !repo || !action) return res.status(400).json({error:'actor, repo, action required'});

  const payload = {
    id: uuidv4(),
    actor, repo, mode, action,
    client_payload: client_payload || {},
    timestamp: new Date().toISOString()
  };
  const signature = signPayload(payload);
  const signed = { payload, signature };

  // persist audit
  saveAudit({ signed, origin: req.ip });

  // emit telemetry stub (replace with RiverOS OTLP)
  console.log('telemetry: mcp.dispatch', {actor, repo, mode, action});

  // dispatch to GitHub repository_dispatch
  const ghUrl = `https://api.github.com/repos/${repo}/dispatches`;
  const body = {
    event_type: 'mcp_command',
    client_payload: { mcp_payload: payload, signature }
  };

  try {
    const r = await fetch(ghUrl, {
      method: 'POST',
      headers: {
        'Authorization': `token ${GH_TOKEN}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });
    if(r.status >= 400){
      const text = await r.text();
      return res.status(502).json({error:'github_dispatch_failed', detail: text});
    }
  } catch(err){
    return res.status(502).json({error:'github_error', detail: String(err)});
  }

  res.json({ok:true, id: payload.id, signature});
});

app.get('/api/v1/audit', authenticate, (req,res)=>{
  try {
    const arr = JSON.parse(fs.readFileSync(AUDIT_STORE_PATH));
    res.json(arr);
  } catch(e){
    res.json([]);
  }
});



// SIWE: nonce and verify endpoints (prototype)
app.get('/api/v1/siwe/nonce', (req,res)=>{
  const n = generateNonce();
  res.json({nonce:n});
});

app.post('/api/v1/siwe/verify', async (req,res)=>{
  const { message, signature } = req.body;
  if(!message || !signature) return res.status(400).json({error:'missing fields'});
  try {
    const v = await verifySiweMessage(message, signature);
    // For prototype, return a base64 token the UI can store and send as Authorization: Bearer <token>
    const tokenObj = {address: v.address, issuedAt: new Date().toISOString()};
    const token = Buffer.from(JSON.stringify(tokenObj)).toString('base64');
    res.json({ok:true, token});
  } catch(e){
    res.status(400).json({error:'siwe_error', detail: String(e)});
  }
});

// RBAC: add role (prototype; protect in prod)
app.post('/api/v1/rbac/add-role', authenticate, (req,res)=>{
  const {address, role} = req.body;
  if(!address || !role) return res.status(400).json({error:'address and role required'});
  addRole(address, role);
  res.json({ok:true});
});

// Approvals: create and sign
app.post('/api/v1/approvals/create', siweAuthMiddleware, (req,res)=>{
  const {payload, required} = req.body;
  const id = createApproval(payload, required || 2);
  res.json({ok:true, id});
});

app.post('/api/v1/approvals/sign', siweAuthMiddleware, (req,res)=>{
  const {id} = req.body;
  if(!id) return res.status(400).json({error:'id required'});
  try {
    const result = signApproval(id, req.user.address);
    res.json({ok:true, result});
  } catch(e){
    res.status(400).json({error: String(e)});
  }
});

app.get('/api/v1/approvals', authenticate, (req,res)=>{
  res.json(listApprovals());
});

app.listen(PORT, ()=> console.log(`MCP prototype listening on ${PORT}`));
