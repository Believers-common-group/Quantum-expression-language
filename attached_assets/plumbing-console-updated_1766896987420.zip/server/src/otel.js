// otel.js - OpenTelemetry OTLP exporter stub (Node)
// Requires: @opentelemetry/api, @opentelemetry/sdk-node, @opentelemetry/exporter-trace-otlp-http
const { NodeSDK } = require('@opentelemetry/sdk-node');
const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-http');
const { diag, DiagConsoleLogger, DiagLogLevel } = require('@opentelemetry/api');

diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.INFO);

function initOtel(){
  try {
    const endpoint = process.env.RIVEROS_ENDPOINT || 'http://localhost:4318/v1/traces';
    const exporter = new OTLPTraceExporter({ url: endpoint });
    const sdk = new NodeSDK({ traceExporter: exporter });
    sdk.start()
      .then(()=> console.log('OpenTelemetry started'))
      .catch((e)=> console.error('OTel start error', e));
    process.on('exit', ()=> { sdk.shutdown().catch(()=>{}); });
  } catch(e){
    console.log('OpenTelemetry init skipped:', e.message);
  }
}

module.exports = { initOtel };
