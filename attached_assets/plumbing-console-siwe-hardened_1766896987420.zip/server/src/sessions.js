// sessions.js - SQLite-backed session store for JWT access + refresh tokens
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = process.env.SESSION_DB_PATH || path.join(__dirname, '../session_store.sqlite');
const db = new sqlite3.Database(dbPath);

db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    address TEXT,
    access_token TEXT,
    refresh_token TEXT,
    issued_at INTEGER,
    expires_at INTEGER
  )`);
});

function saveSession(session){
  const stmt = db.prepare(`INSERT OR REPLACE INTO sessions (id,address,access_token,refresh_token,issued_at,expires_at) VALUES(?,?,?,?,?,?)`);
  stmt.run(session.id, session.address, session.access_token, session.refresh_token, session.issued_at, session.expires_at);
  stmt.finalize();
}

function getSessionByRefresh(refreshToken){
  return new Promise((resolve,reject)=>{
    db.get(`SELECT * FROM sessions WHERE refresh_token = ?`, [refreshToken], (err,row)=>{
      if(err) return reject(err);
      resolve(row);
    });
  });
}

function deleteSession(id){
  db.run(`DELETE FROM sessions WHERE id = ?`, [id]);
}

module.exports = { saveSession, getSessionByRefresh, deleteSession };
