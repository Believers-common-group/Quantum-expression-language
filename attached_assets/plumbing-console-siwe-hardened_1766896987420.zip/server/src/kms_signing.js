// kms_signing.js - AWS KMS signing helper (Node.js, AWS SDK v3)
// Requires AWS_REGION and AWS_KMS_KEY_ID env vars and AWS credentials (env or role)
const { KMSClient, SignCommand } = require('@aws-sdk/client-kms');
const crypto = require('crypto');

const region = process.env.AWS_REGION;
const keyId = process.env.AWS_KMS_KEY_ID;
let client = null;
if(region) client = new KMSClient({ region });

async function signWithKMS(payload){
  if(!client || !keyId) throw new Error('KMS not configured (AWS_REGION,AWS_KMS_KEY_ID)');
  // Use SHA-256 digest over JSON payload
  const data = Buffer.from(JSON.stringify(payload));
  const digest = crypto.createHash('sha256').update(data).digest();
  const params = {
    KeyId: keyId,
    Message: digest,
    MessageType: 'DIGEST',
    SigningAlgorithm: 'RSASSA_PSS_SHA_256' // ensure your key supports this
  };
  const cmd = new SignCommand(params);
  const res = await client.send(cmd);
  // res.Signature is ArrayBuffer -> Buffer
  const sig = Buffer.from(res.Signature).toString('base64');
  return sig;
}

module.exports = { signWithKMS };
