// db.js - simple SQLite session store for prototype
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const DB_PATH = process.env.SESSION_DB_PATH || path.join(__dirname, '..', 'data', 'plumbing.db');
const fs = require('fs');
const dir = path.dirname(DB_PATH);
if(!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

const db = new sqlite3.Database(DB_PATH);
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS refresh_tokens (
    id TEXT PRIMARY KEY,
    address TEXT,
    token TEXT,
    issued_at INTEGER
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS revoked_tokens (
    id TEXT PRIMARY KEY,
    token TEXT,
    revoked_at INTEGER
  )`);
});

function saveRefreshToken(id, address, token){
  return new Promise((resolve, reject)=>{
    const stmt = db.prepare('INSERT INTO refresh_tokens(id,address,token,issued_at) VALUES(?,?,?,?)');
    stmt.run(id, address, token, Date.now(), function(err){
      if(err) return reject(err);
      resolve();
    });
  });
}
function deleteRefreshToken(id){
  return new Promise((resolve, reject)=>{
    db.run('DELETE FROM refresh_tokens WHERE id = ?', [id], function(err){
      if(err) return reject(err);
      resolve();
    });
  });
}
function getRefreshToken(id){
  return new Promise((resolve, reject)=>{
    db.get('SELECT id,address,token,issued_at FROM refresh_tokens WHERE id = ?', [id], function(err,row){
      if(err) return reject(err);
      resolve(row);
    });
  });
}
function revokeToken(id, token){
  return new Promise((resolve,reject)=>{
    const stmt = db.prepare('INSERT INTO revoked_tokens(id,token,revoked_at) VALUES(?,?,?)');
    stmt.run(id, token, Date.now(), function(err){
      if(err) return reject(err);
      resolve();
    });
  });
}
function isTokenRevoked(id){
  return new Promise((resolve,reject)=>{
    db.get('SELECT id FROM revoked_tokens WHERE id = ?', [id], function(err,row){
      if(err) return reject(err);
      resolve(!!row);
    });
  });
}

module.exports = { saveRefreshToken, deleteRefreshToken, getRefreshToken, revokeToken, isTokenRevoked };
