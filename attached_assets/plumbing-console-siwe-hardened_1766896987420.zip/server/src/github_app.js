// github_app.js - GitHub App authentication helper (using @octokit/auth-app and @octokit/rest)
// Requires: GH_APP_ID, GH_APP_INSTALLATION_ID (optional), GH_APP_PRIVATE_KEY (PEM)
const { createAppAuth } = require('@octokit/auth-app');
const { Octokit } = require('@octokit/rest');

async function getInstallationToken(owner, repo){
  const appId = process.env.GH_APP_ID;
  const privateKey = process.env.GH_APP_PRIVATE_KEY;
  if(!appId || !privateKey) throw new Error('GH App not configured');
  const auth = createAppAuth({
    id: appId,
    privateKey,
  });
  // get installation id for the repo
  const appOctokit = new Octokit({ authStrategy: createAppAuth, auth: { id: appId, privateKey } });
  // fetch installations and find installation for owner/org
  const installations = await appOctokit.request('GET /app/installations');
  let inst = installations.data.find(i => i.account && (i.account.login.toLowerCase() === owner.toLowerCase()));
  if(!inst){
    // fallback to first installation
    inst = installations.data[0];
    if(!inst) throw new Error('No installations found for app');
  }
  const installationId = inst.id;
  // create installation token
  const res = await appOctokit.request('POST /app/installations/{installation_id}/access_tokens', { installation_id: installationId });
  return res.data.token;
}

// helper to create Octokit for repo
async function octokitForRepo(fullRepo){
  // fullRepo = owner/repo
  const [owner, repo] = fullRepo.split('/');
  const token = await getInstallationToken(owner, repo);
  return new Octokit({ auth: token });
}

module.exports = { getInstallationToken, octokitForRepo };
