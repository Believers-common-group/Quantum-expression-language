// vault_signing.js - simple HashiCorp Vault signing helper (placeholder)
// Requires: VAULT_ADDR, VAULT_TOKEN, VAULT_KEY_PATH (transit key name)
const fetch = require('node-fetch');
const crypto = require('crypto');
const base64url = (b) => Buffer.from(b).toString('base64');

async function signWithVault(payload) {
  const addr = process.env.VAULT_ADDR;
  const token = process.env.VAULT_TOKEN;
  const key = process.env.VAULT_KEY_PATH || 'mcp-sign-key';
  if(!addr || !token) throw new Error('Vault config missing');
  const message = Buffer.from(JSON.stringify(payload)).toString('base64');
  const url = `${addr}/v1/transit/sign/${key}`;
  const res = await fetch(url, {
    method:'POST',
    headers:{
      'X-Vault-Token': token,
      'Content-Type':'application/json'
    },
    body: JSON.stringify({ input: message, prehashed: false })
  });
  const body = await res.json();
  if(!res.ok) throw new Error('Vault sign failed: '+JSON.stringify(body));
  // Vault returns signature in body.data.signature
  return body.data.signature;
}

module.exports = { signWithVault };
