// siwe.js - Hardened SIWE with JWT sessions and refresh tokens (prototype)
const { SiweMessage } = require('siwe');
const ethers = require('ethers');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { saveRefreshToken, getRefreshToken, deleteRefreshToken, revokeToken, isTokenRevoked } = require('./db');

const JWT_SECRET = process.env.JWT_SECRET || 'replace_with_strong_secret';
const ACCESS_EXPIRES = process.env.ACCESS_EXPIRES || '15m';
const REFRESH_EXPIRES = process.env.REFRESH_EXPIRES || '30d';

function generateNonce(){
  // siwe library also supports generating nonces; keep simple
  return ethers.utils.hexlify(ethers.utils.randomBytes(8));
}

async function verifySiweMessage(message, signature){
  const siwe = new SiweMessage(message);
  const fields = await siwe.validate(signature);
  return fields; // contains address
}

function createAccessToken(address){
  const payload = { address };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_EXPIRES });
}
async function createRefreshToken(address){
  const id = uuidv4();
  const token = jwt.sign({ address, id }, JWT_SECRET, { expiresIn: REFRESH_EXPIRES });
  await saveRefreshToken(id, address, token);
  return { id, token };
}

async function refreshAccessToken(id, token){
  const stored = await getRefreshToken(id);
  if(!stored) throw new Error('refresh_not_found');
  if(stored.token !== token) throw new Error('token_mismatch');
  const revoked = await isTokenRevoked(id);
  if(revoked) throw new Error('token_revoked');
  // verify token validity
  jwt.verify(token, JWT_SECRET);
  // issue new access token
  const access = createAccessToken(stored.address);
  return access;
}

async function revokeRefreshToken(id){
  const rec = await getRefreshToken(id);
  if(rec){
    await revokeToken(id, rec.token);
    await deleteRefreshToken(id);
  }
}

// Middleware: validate access JWT from Authorization: Bearer <token>
function accessAuthMiddleware(req,res,next){
  const auth = req.headers['authorization'] || '';
  if(!auth.startsWith('Bearer ')) return res.status(401).json({error:'missing token'});
  const token = auth.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = { address: payload.address };
    return next();
  } catch(e){
    return res.status(401).json({error:'invalid_token', detail: String(e)});
  }
}

module.exports = { generateNonce, verifySiweMessage, createAccessToken, createRefreshToken, refreshAccessToken, revokeRefreshToken, accessAuthMiddleware };
