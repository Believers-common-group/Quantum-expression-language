Server notes:
- This is a prototype. Replace HMAC signing with HSM-backed signing.
- Replace simple token auth with OIDC / WebAuthn in production.
- Add input validation, rate limiting, and RBAC checks.
