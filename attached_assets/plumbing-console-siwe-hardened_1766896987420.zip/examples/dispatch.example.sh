# Example CURL to call MCP dispatch (replace values)
curl -X POST http://localhost:4000/api/v1/dispatch \
  -H "Authorization: Bearer changeme" \
  -H "Content-Type: application/json" \
  -d '{
    "actor":"kay@believers",
    "repo":"believers-common/virtual-silk-road",
    "mode":"textile",
    "action":"supply-recce",
    "client_payload":{"recce_depth":"shallow"}
  }'
