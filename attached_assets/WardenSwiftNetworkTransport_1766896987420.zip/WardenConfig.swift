import Foundation

public struct WardenConfig {
    public var ingestionEndpoint: URL?
    public var ingestionApiKey: String?
    public var sendImmediately: Bool = false
    public var maxBatchSize: Int = 50
    public var allowNetwork: Bool = true

    public init(ingestionEndpoint: URL? = nil,
                ingestionApiKey: String? = nil,
                sendImmediately: Bool = false,
                maxBatchSize: Int = 50,
                allowNetwork: Bool = true) {
        self.ingestionEndpoint = ingestionEndpoint
        self.ingestionApiKey = ingestionApiKey
        self.sendImmediately = sendImmediately
        self.maxBatchSize = maxBatchSize
        self.allowNetwork = allowNetwork
    }
}