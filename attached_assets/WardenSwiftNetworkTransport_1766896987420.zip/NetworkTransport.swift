import Foundation

class NetworkTransport {
    static let shared = NetworkTransport()
    private init() {}

    func send(event: WardenEvent,
              to endpoint: URL,
              apiKey: String? = nil,
              completion: ((Bool) -> Void)? = nil) {

        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        if let key = apiKey {
            request.setValue(key, forHTTPHeaderField: "x-api-key")
        }

        do {
            let data = try JSONEncoder().encode(event)
            request.httpBody = data

            let task = URLSession.shared.dataTask(with: request) { _, response, error in
                if let err = error {
                    NSLog("Warden transport error: %@", err.localizedDescription)
                    completion?(false)
                    return
                }

                guard let http = response as? HTTPURLResponse,
                      200...299 ~= http.statusCode else {
                    completion?(false)
                    return
                }

                completion?(true)
            }
            task.resume()

        } catch {
            NSLog("Warden encode error: %@", error.localizedDescription)
            completion?(false)
        }
    }
}