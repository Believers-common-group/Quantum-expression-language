import Foundation
import UIKit

public final class WardenLogger {

    public static let shared = WardenLogger()

    private var config: WardenConfig = WardenConfig()
    private var queue: [WardenEvent] = []
    private let serial = DispatchQueue(label: "com.wardensdk.queue")

    private init() {}

    public func configure(_ cfg: WardenConfig) {
        serial.sync { self.config = cfg }
    }

    public func log(type: WardenEventType, metadata: [String: String] = [:]) {

        let sanitized = metadata.filter { key, _ in
            let lower = key.lowercased()
            return !lower.contains("token")
                && !lower.contains("email")
                && !lower.contains("id_token")
                && !lower.contains("access")
        }

        let ev = WardenEvent(
            type: type,
            appBundle: Bundle.main.bundleIdentifier,
            projectId: Bundle.main.object(forInfoDictionaryKey: "FIREBASE_PROJECT_ID") as? String,
            metadata: sanitized
        )

        serial.async {
            self.queue.append(ev)
            NSLog("WARDEN_EVENT: %@", self.brief(event: ev))

            if self.config.sendImmediately,
               self.config.allowNetwork,
               let endpoint = self.config.ingestionEndpoint {

                NetworkTransport.shared.send(
                    event: ev,
                    to: endpoint,
                    apiKey: self.config.ingestionApiKey
                )
            } else if self.queue.count >= self.config.maxBatchSize {
                self.flushBatch()
            }
        }
    }

    private func brief(event: WardenEvent) -> String {
        var dict: [String: String] = [
            "id": event.id,
            "type": event.type.rawValue,
            "t": event.timestamp
        ]

        if let meta = event.metadata {
            for (k, v) in meta.prefix(3) { dict[k] = v }
        }

        return dict.description
    }

    public func flushBatch() {
        guard let endpoint = config.ingestionEndpoint,
              config.allowNetwork else { return }

        serial.async {
            let batch = Array(self.queue.prefix(self.config.maxBatchSize))

            for ev in batch {
                NetworkTransport.shared.send(
                    event: ev,
                    to: endpoint,
                    apiKey: self.config.ingestionApiKey
                )
            }

            self.queue.removeFirst(
                min(self.queue.count, self.config.maxBatchSize)
            )
        }
    }
}