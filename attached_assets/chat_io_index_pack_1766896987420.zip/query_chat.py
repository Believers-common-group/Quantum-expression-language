#!/usr/bin/env python3
import sqlite3, sys, json, argparse
from pathlib import Path

def list_turns(db):
    con = sqlite3.connect(db)
    cur = con.cursor()
    cur.execute("""
      SELECT t.idx, COALESCE(i.role,o.role), COALESCE(i.content,o.content)
      FROM turn t
      LEFT JOIN io_input i ON i.turn_id = t.id
      LEFT JOIN io_output o ON o.turn_id = t.id
      ORDER BY t.idx
    """)
    rows = cur.fetchall()
    con.close()
    for idx, role, content in rows:
        print(f"#{idx:02d} [{role}]: {content}")

def list_artifacts(db):
    con = sqlite3.connect(db)
    cur = con.cursor()
    cur.execute("""
      SELECT t.idx, a.kind, a.uri, a.meta_json
      FROM artifact a
      JOIN turn t ON t.id = a.turn_id
      ORDER BY t.idx
    """)
    for idx, kind, uri, meta in cur.fetchall():
        name = json.loads(meta).get("name","")
        print(f"turn {idx:02d} :: {kind} :: {name} :: {uri}")
    con.close()

def search(db, q):
    con = sqlite3.connect(db)
    cur = con.cursor()
    like = f"%{q}%"
    cur.execute("""
      SELECT t.idx, COALESCE(i.role,o.role), COALESCE(i.content,o.content)
      FROM turn t
      LEFT JOIN io_input i ON i.turn_id = t.id
      LEFT JOIN io_output o ON o.turn_id = t.id
      WHERE COALESCE(i.content,'') LIKE ? OR COALESCE(o.content,'') LIKE ?
      ORDER BY t.idx
    """, (like, like))
    for idx, role, content in cur.fetchall():
        print(f"#{idx:02d} [{role}]: {content}")
    con.close()

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Query chat I/O index DB")
    ap.add_argument("--db", default="chat_io_index.db")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("turns")
    sub.add_parser("artifacts")
    sp = sub.add_parser("search")
    sp.add_argument("q")
    args = ap.parse_args()

    if args.cmd == "turns":
        list_turns(args.db)
    elif args.cmd == "artifacts":
        list_artifacts(args.db)
    elif args.cmd == "search":
        search(args.db, args.q)
    else:
        ap.print_help()
