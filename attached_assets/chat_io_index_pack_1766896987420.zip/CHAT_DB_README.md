# Chat I&O SQLite Pack

Files:
- `chat_io_index.db` — SQLite with DAO schema (conversation/turn/input/output/artifact/memory)
- `query_chat.py` — tiny CLI to browse turns, artifacts, or do a LIKE search
- `chat_index.json` — compact JSON index of the conversation (if present)

## Quick start
```bash
# list turns
python3 query_chat.py --db chat_io_index.db turns

# list artifacts
python3 query_chat.py --db chat_io_index.db artifacts

# fuzzy search
python3 query_chat.py --db chat_io_index.db search 'starter kit'
```

## Notes
- This DB is seeded from the lightweight index we built during the session.
- No persistent memories were stored in this chat. If you want to add account-level defaults,
  create rows in the `memory` table (scope='account') keyed by your settings.
